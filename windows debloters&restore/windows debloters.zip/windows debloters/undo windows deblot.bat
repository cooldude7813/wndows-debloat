@echo off
setlocal EnableDelayedExpansion
title Restore Everything

:: Admin Check
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo This script must be run as Administrator.
    echo Right-click the file and choose "Run as administrator".
    pause
    exit /b
)

:: Restore Point
set "RP_NAME=Restore All - %DATE% %TIME%"
echo Creating restore point...
wmic.exe /Namespace:\\root\default Path SystemRestore Call CreateRestorePoint "%RP_NAME%", 100, 7 >nul 2>nul

if %errorlevel% neq 0 (
    echo Restore point could not be created.
    echo Fix this by:
    echo  - Enable System Protection for drive C:
    echo  - Ensure Volume Shadow Copy (VSS) is running
    echo  - Wait 24 hours if a restore point was recently created
    pause
    exit /b
)

echo Restore point created successfully.
echo Restoring apps...

:: Re-register all Appx packages
powershell -NoProfile -Command ^
"Get-AppxPackage -AllUsers | ForEach-Object { ^
    try {Add-AppxPackage -DisableDevelopmentMode -Register ($_.InstallLocation + '\AppXManifest.xml')} catch {} ^
}" >nul 2>nul

:: Re-enable ads/sync notifications
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SystemPaneSuggestionsEnabled /t REG_DWORD /d 1 /f >nul 2>nul
reg add "HKCU\Software\Microsoft\Windows\Explorer\Advanced" /v ShowSyncProviderNotifications /t REG_DWORD /d 1 /f >nul 2>nul

:: Re-enable telemetry tasks
schtasks /Change /TN "Microsoft\Windows\Application Experience\ProgramDataUpdater" /Enable >nul 2>nul
schtasks /Change /TN "Microsoft\Windows\Customer Experience Improvement Program\Consolidator" /Enable >nul 2>nul
schtasks /Change /TN "Microsoft\Windows\Customer Experience Improvement Program\UsbCeip" /Enable >nul 2>nul

:: Re-enable Copilot
reg delete "HKCU\Software\Microsoft\Windows\WindowsCopilot" /v TurnOffWindowsCopilot /f >nul 2>nul

:: Re-enable OneDrive
%SystemRoot%\System32\OneDriveSetup.exe >nul 2>nul

echo Restore complete.
echo If anything still feels off, use System Restore (rstrui.exe).
pause
exit /b
