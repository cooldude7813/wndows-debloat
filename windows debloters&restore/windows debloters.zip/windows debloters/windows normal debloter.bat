@echo off
setlocal EnableDelayedExpansion
title Normal Debloater

:: Admin Check
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo This script must be run as Administrator.
    echo Right-click the file and choose "Run as administrator".
    pause
    exit /b
)

:: Restore Point
set "RP_NAME=Normal Debloat - %DATE% %TIME%"
echo Creating restore point...
wmic.exe /Namespace:\\root\default Path SystemRestore Call CreateRestorePoint "%RP_NAME%", 100, 7 >nul 2>nul

if %errorlevel% neq 0 (
    echo Restore point could not be created.
    echo Fix this by:
    echo  - Enable System Protection for drive C:
    echo  - Ensure Volume Shadow Copy (VSS) is running
    echo  - Wait 24 hours if a restore point was recently created
    pause
    exit /b
)

echo Restore point created successfully.
echo Debloating...

:: Safe Titus-style Appx removals (more aggressive)
powershell -NoProfile -Command "Get-AppxPackage *3DViewer*                | Remove-AppxPackage" >nul 2>nul
powershell -NoProfile -Command "Get-AppxPackage *MixedReality*            | Remove-AppxPackage" >nul 2>nul
powershell -NoProfile -Command "Get-AppxPackage *Paint3D*                 | Remove-AppxPackage" >nul 2>nul
powershell -NoProfile -Command "Get-AppxPackage *People*                  | Remove-AppxPackage" >nul 2>nul
powershell -NoProfile -Command "Get-AppxPackage *SkypeApp*                | Remove-AppxPackage" >nul 2>nul
powershell -NoProfile -Command "Get-AppxPackage *OfficeHub*               | Remove-AppxPackage" >nul 2>nul
powershell -NoProfile -Command "Get-AppxPackage *Solitaire*               | Remove-AppxPackage" >nul 2>nul
powershell -NoProfile -Command "Get-AppxPackage *FeedbackHub*             | Remove-AppxPackage" >nul 2>nul
powershell -NoProfile -Command "Get-AppxPackage *Cortana*                 | Remove-AppxPackage" >nul 2>nul
powershell -NoProfile -Command "Get-AppxPackage *WindowsMaps*             | Remove-AppxPackage" >nul 2>nul
powershell -NoProfile -Command "Get-AppxPackage *BingWeather*             | Remove-AppxPackage" >nul 2>nul
powershell -NoProfile -Command "Get-AppxPackage *WindowsAlarms*           | Remove-AppxPackage" >nul 2>nul
powershell -NoProfile -Command "Get-AppxPackage *WindowsCamera*           | Remove-AppxPackage" >nul 2>nul
powershell -NoProfile -Command "Get-AppxPackage *windowscommunicationsapps* | Remove-AppxPackage" >nul 2>nul

:: Remove Xbox + Gaming
powershell -NoProfile -Command "Get-AppxPackage *Xbox*                    | Remove-AppxPackage" >nul 2>nul
powershell -NoProfile -Command "Get-AppxPackage *GamingApp*               | Remove-AppxPackage" >nul 2>nul

:: Keep Edge + Notepad

:: Disable ads
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager" /v SystemPaneSuggestionsEnabled /t REG_DWORD /d 0 /f >nul 2>nul
reg add "HKCU\Software\Microsoft\Windows\Explorer\Advanced" /v ShowSyncProviderNotifications /t REG_DWORD /d 0 /f >nul 2>nul

:: Disable telemetry tasks
schtasks /Change /TN "Microsoft\Windows\Application Experience\ProgramDataUpdater" /Disable >nul 2>nul
schtasks /Change /TN "Microsoft\Windows\Customer Experience Improvement Program\Consolidator" /Disable >nul 2>nul
schtasks /Change /TN "Microsoft\Windows\Customer Experience Improvement Program\UsbCeip" /Disable >nul 2>nul

:: Disable Copilot
reg add "HKCU\Software\Microsoft\Windows\WindowsCopilot" /v TurnOffWindowsCopilot /t REG_DWORD /d 1 /f >nul 2>nul

echo.
echo Debloat complete.

:: OneDrive Prompt
echo.
set /p REMOVEOD="Remove OneDrive? (Y/N): "

if /I "%REMOVEOD%"=="Y" (
    echo Removing OneDrive...
    taskkill /f /im OneDrive.exe >nul 2>nul
    %SystemRoot%\System32\OneDriveSetup.exe /uninstall >nul 2>nul
    echo OneDrive removed.
) else (
    echo Keeping OneDrive enabled.
)

pause
exit /b
